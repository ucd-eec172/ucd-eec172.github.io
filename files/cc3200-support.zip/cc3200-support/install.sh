#!/bin/bash

# make script dir working directory and save as variable
SCRIPT_DIR=$(cd "$(dirname "${0}")" && pwd)

# Default variable values
verbose_mode=false
prefix="~/ti"

# Function to display script usage
usage() {
    echo "Usage: $0 [OPTIONS]"
    echo "Options:"
    echo " -h, --help          Display this help message"
    echo " -v, --verbose       Enable verbose mode"
    echo " -p, --prefix FILE   Specify install directory (default: '~/ti')"
}

has_argument() {
    [[ ("$1" == *=* && -n ${1#*=}) || ( ! -z "$2" && "$2" != -*)  ]];
}

extract_argument() {
    echo "${2:-${1#*=}}"
}

# Function to handle options and arguments
handle_options() {
    while [ $# -gt 0 ]; do
        case $1 in
            -h | --help)
            usage
            exit 0
            ;;
            
            -v | --verbose) # handle verbose flag
            verbose_mode=true
            ;;

            -p | --prefix*) # handle prefix flag
            if ! has_argument $@; then
                echo "directory not specified" >&2
                usage
                exit 1
            fi

            prefix=$(extract_argument $@)

            shift
            ;;
            
            *)
            echo "Invalid option: $1" >&2
            usage
            exit 1
            ;;
        esac
        shift
    done
}

# Main script execution

handle_options "$@"

# Perform the desired actions based on the provided flags and arguments
if [ "$verbose_mode" = true ]; then
    echo "Verbose mode enabled."
fi

if [ -n "$prefix" ]; then
    echo "Prefix specified: $prefix"
    $verbose_mode && echo "make prefix"
    [ -d "$prefix" ] || mkdir -p $prefix
    mkdir $prefix/lib
fi

# install by extracting zip files to prefix
echo "extracting cc3200 sdk and servicepack to $prefix/lib"
if $verbose_mode ; then
    unzip -d $prefix/lib $SCRIPT_DIR/cc3200sdk_1.5.0.zip
    unzip -d $prefix/lib $SCRIPT_DIR/cc3200servicepack.zip
else
    unzip -q -d $prefix/lib $SCRIPT_DIR/cc3200sdk_1.5.0.zip
    unzip -q -d $prefix/lib $SCRIPT_DIR/cc3200servicepack.zip
fi

echo "done"
